class Info {
    constructor() {

    }

    show() {
        background(150);
        fill(0);
        textSize(15);
        text("Press S to make the dog sit", 20, 20);
        text("F to feed", 65, 40);
        text("B to make him sleep on the bed", 65, 60);
        text("D to think 'if he dies'", 65, 80);
        text("G to take him to garden", 65, 100);
        text("H to have your pet vaccination", 65, 120);
        text("L to see when he is lazy", 65, 140);
        text("S to tak ehim to living room", 65, 160);
        text("RIGHT ARROW to make him run right", 65, 180);
        text("LEFT ARROW to make him run left", 65, 200);
        text("V to see the vacation shedule", 65, 220);
        text("W to take him to washroom", 65, 240);
    }

    hide() {

    }
}